#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

struct NormalMenu {
   char date[50];
   char soup[50];
   char main_dish[50];
   char side_dish[50];
   char extra[50];
   int counts[3]; 
};

struct VeganMenu {
   char date[50];
   char soup[50];
   char main_dish[50];
   char side_dish[50];
   char extra[50];
   int counts[3];
};

struct VegetarianMenu {
   char date[50];
   char soup[50];
   char main_dish[50];
   char side_dish[50];
   char extra[50];
   int counts[3];
};

struct Cafeteria {
   char*  month;
   struct NormalMenu* normal_menus;
   struct VeganMenu* vegan_menus;
   struct VegetarianMenu* vegetarian_menus;
} cafeteria;

int count_days(char* file_name) {
    FILE* myFile;
    // Opening file in reading mode
    myFile = fopen(file_name, "r");
    if (myFile == NULL)
    {
       exit(1);
    }
    char buffer[200];
    int day_count = 0;
    while (fgets(buffer, 200, myFile)) {
        char *token = strtok(buffer, ",");
        if (strcmp(token, "\"Normal\"") == 0) {
            day_count++;
        }
    }
    fclose(myFile);
    return day_count;
}

void initialize_menus(char* file_name, int day_count) {
    cafeteria.normal_menus = (struct NormalMenu*) malloc(day_count * sizeof(struct NormalMenu));
    cafeteria.vegan_menus = (struct VeganMenu*) malloc(day_count * sizeof(struct VeganMenu));
    cafeteria.vegetarian_menus = (struct VegetarianMenu*) malloc(day_count * sizeof(struct VegetarianMenu));

    FILE* myFile;
    // Opening file in reading mode
    myFile = fopen(file_name, "r");
    if (myFile == NULL)
    {
       exit(1);
    }

    int normal_c = 0;
    int vegan_c = 0;
    int vegetarian_c = 0;
    char buffer[200];
    while (fgets(buffer, 200, myFile)) {
        // If you need all the values in a row
        char *token = strtok(buffer, ",");
        if (strcmp(token, "\"Normal\"") == 0) {
            struct NormalMenu temp_menu;
            /*temp_menu.date = (char*) malloc(50 * sizeof(char));
            temp_menu.soup = (char*) malloc(50 * sizeof(char));
            temp_menu.main_dish = (char*) malloc(50 * sizeof(char));
            temp_menu.side_dish = (char*) malloc(50 * sizeof(char));
            temp_menu.extra = (char*) malloc(50 * sizeof(char));

            char date_token[50] = "";
            char soup_token[50] = "";
            char main_dish_token[50] = "";
            char side_dish_token[50] = "";
            char extra_token[50] = "";*/

            strcpy(temp_menu.date, strtok(NULL, ","));
            // temp_menu.date = date_token;

            strcpy(temp_menu.soup, strtok(NULL, ","));
            // temp_menu.soup = soup_token;

            strcpy(temp_menu.main_dish, strtok(NULL, ","));
            // temp_menu.main_dish = main_dish_token;

            strcpy(temp_menu.side_dish, strtok(NULL, ","));
            // temp_menu.side_dish = side_dish_token;

            strcpy(temp_menu.extra, strtok(NULL, ","));
            // temp_menu.extra = extra_token;

            // temp_menu.counts = (int*) malloc(3 * sizeof(int));
            temp_menu.counts[0] = 0;
            temp_menu.counts[1] = 0;
            temp_menu.counts[2] = 0;

            if (normal_c == 0 || normal_c == day_count-1) {
                printf("~ ~ ~ ~ ~ ~ ~ ~ Normal menu for the first and last days of the month:\n");
                printf("date--> %s\n", temp_menu.date);
                printf("soup--> %s\n", temp_menu.soup);
                printf("main_dish--> %s\n", temp_menu.main_dish);
                printf("side_dish--> %s\n", temp_menu.side_dish);
                printf("extra--> %s\n\n", temp_menu.extra);
            }

            cafeteria.normal_menus[normal_c] = temp_menu;
            normal_c++;
        }      
        else if (strcmp(token, "\"Vegan\"") == 0) {
            struct VeganMenu temp_menu;

            strcpy(temp_menu.date, strtok(NULL, ","));
            strcpy(temp_menu.soup, strtok(NULL, ","));
            strcpy(temp_menu.main_dish, strtok(NULL, ","));
            strcpy(temp_menu.side_dish, strtok(NULL, ","));
            strcpy(temp_menu.extra, strtok(NULL, ","));

            temp_menu.counts[0] = 0;
            temp_menu.counts[1] = 0;
            temp_menu.counts[2] = 0;

            if (vegan_c == 0 || vegan_c == day_count-1) {
                printf("~ ~ ~ ~ ~ ~ ~ ~ Vegan menu for the first and last days of the month:\n");
                printf("date--> %s\n", temp_menu.date);
                printf("soup--> %s\n", temp_menu.soup);
                printf("main_dish--> %s\n", temp_menu.main_dish);
                printf("side_dish--> %s\n", temp_menu.side_dish);
                printf("extra--> %s\n\n", temp_menu.extra);
            }

            cafeteria.vegan_menus[vegan_c] = temp_menu;
            vegan_c++;
        }      
        else if (strcmp(token, "\"Vegetarian\"") == 0) {
            struct VegetarianMenu temp_menu;

            strcpy(temp_menu.date, strtok(NULL, ","));
            strcpy(temp_menu.soup, strtok(NULL, ","));
            strcpy(temp_menu.main_dish, strtok(NULL, ","));
            strcpy(temp_menu.side_dish, strtok(NULL, ","));
            strcpy(temp_menu.extra, strtok(NULL, ","));
            
            temp_menu.counts[0] = 0;
            temp_menu.counts[1] = 0;
            temp_menu.counts[2] = 0;

            if (vegetarian_c == 0 || vegetarian_c == day_count-1) {
                printf("~ ~ ~ ~ ~ ~ ~ ~ Vegetarian menu for the first and last days of the month:\n");
                printf("date--> %s\n", temp_menu.date);
                printf("soup--> %s\n", temp_menu.soup);
                printf("main_dish--> %s\n", temp_menu.main_dish);
                printf("side_dish--> %s\n", temp_menu.side_dish);
                printf("extra--> %s\n\n", temp_menu.extra);
            }

            cafeteria.vegetarian_menus[vegetarian_c] = temp_menu;
            vegetarian_c++;
        }
    }
    fclose(myFile);
}

void get_month_from_file_name(){
    char file_name_token[] = "cafeteria_march_menu.csv";
    char* token = strtok(file_name_token, "_");
    token = strtok(NULL, "_");
    cafeteria.month = token;
}

void record_customer_counts(int day_count) {
    srand(time(NULL));  // For randomness !!!!!

    for(int i=0; i<day_count; i++) {
        for(int j=0; j<3; j++) {
            cafeteria.normal_menus[i].counts[j] = rand() % 51;
            cafeteria.vegan_menus[i].counts[j] = rand() % 51;
            cafeteria.vegetarian_menus[i].counts[j] = rand() % 51;
        }
    }
}

void calc_and_show_income(int day_count) {
    int normal_sales = 0;
    int vegan_sales = 0;
    int vegetarian_sales = 0;
    int student_sales = 0;
    int academic_sales = 0;
    int admin_sales = 0;
    int prices[3] = {6, 16, 12};

    for(int i=0; i<day_count; i++) {
        for(int j=0; j<3; j++) {
            normal_sales += cafeteria.normal_menus[i].counts[j] * prices[j];
            vegan_sales += cafeteria.vegan_menus[i].counts[j] * prices[j];
            vegetarian_sales += cafeteria.vegetarian_menus[i].counts[j] * prices[j];
        }
        student_sales += (cafeteria.normal_menus[i].counts[0] + cafeteria.vegan_menus[i].counts[0] + cafeteria.vegetarian_menus[i].counts[0]) * 6;
        academic_sales += (cafeteria.normal_menus[i].counts[1] + cafeteria.vegan_menus[i].counts[1] + cafeteria.vegetarian_menus[i].counts[1]) * 16;
        admin_sales += (cafeteria.normal_menus[i].counts[2] + cafeteria.vegan_menus[i].counts[2] + cafeteria.vegetarian_menus[i].counts[2]) * 12;
    }
    int total_sales = normal_sales + vegan_sales + vegetarian_sales;

    printf("\n\n************ The Sales Results ************\n");
    printf("Normal menu sales: %d TL, Vegan menu sales: %d TL, Vegetarian menu sales: %d TL\n", normal_sales, vegan_sales, vegetarian_sales);
    printf("Student sales: %d TL, Academic personel sales: %d TL, Administrative personal sales: %d TL\n", student_sales, academic_sales, admin_sales);
    printf("Total sale income: %d TL\n", total_sales);
}


int main() {
    get_month_from_file_name("cafeteria_march_menu.csv");
    printf("Month name --> %s\n\n", cafeteria.month);

    int day_count = count_days("cafeteria_march_menu.csv");

    initialize_menus("cafeteria_march_menu.csv", day_count);

    printf("**************** Example Outputs ******************\n");
    printf("Example output for normal menu ====> %s | %s | %s | %s | %s\n", cafeteria.normal_menus[2].date, cafeteria.normal_menus[2].soup, 
        cafeteria.normal_menus[2].main_dish, cafeteria.normal_menus[2].side_dish, cafeteria.normal_menus[2].extra);

    printf("Example output for vegan menu ====> %s | %s | %s | %s | %s\n", cafeteria.vegan_menus[7].date, cafeteria.vegan_menus[7].soup, 
        cafeteria.vegan_menus[7].main_dish, cafeteria.vegan_menus[7].side_dish, cafeteria.vegan_menus[7].extra);

    printf("Example output for vegetarian menu ====> %s | %s | %s | %s | %s\n", cafeteria.vegetarian_menus[13].date, cafeteria.vegetarian_menus[13].soup, 
        cafeteria.vegetarian_menus[13].main_dish, cafeteria.vegetarian_menus[13].side_dish, cafeteria.vegetarian_menus[13].extra);

    record_customer_counts(day_count);

    printf("Counts of example output for normal menu of March 3rd ====> %d, %d, %d\n", cafeteria.normal_menus[2].counts[0], cafeteria.normal_menus[2].counts[1], 
        cafeteria.normal_menus[2].counts[2]);
    printf("Counts of example output for vegan menu of March 10th ====> %d, %d, %d\n", cafeteria.vegan_menus[7].counts[0], cafeteria.vegan_menus[7].counts[1], 
        cafeteria.vegan_menus[7].counts[2]);
    printf("Counts of example output for vegetarian menu of March 20th ====> %d, %d, %d\n", cafeteria.vegetarian_menus[13].counts[0], cafeteria.vegetarian_menus[13].counts[1], 
        cafeteria.vegetarian_menus[13].counts[2]);

    calc_and_show_income(day_count);

    free(cafeteria.normal_menus);
    free(cafeteria.vegan_menus);
    free(cafeteria.vegetarian_menus);
    return 0;
}
