//Kutay Bilgiç 260201023
//Nil Su Demir 270201045
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


//we have defined the structs we will use
typedef struct {
    char date[10];
    char soup[30];
    char main_dish[30];
    char side_dish[30];
    char extra[30];
    int sale_count[3];
} Normal_menu;

typedef struct  {
    Normal_menu* menu_list;
    int size;
} DailyNormalMenu;

typedef struct {
    char date[10];
    char soup[30];
    char main_dish[30];
    char side_dish[30];
    char extra[30];
    int sale_count[3];
} Vegan_menu;

typedef struct  {
    Vegan_menu* menu_list;
    int size;
}DailyVeganMenu;

typedef struct {
    char date[10];
    char soup[30];
    char main_dish[30];
    char side_dish[30];
    char extra[30];
    int sale_count[3];
}Vegeterian_menu;

typedef struct  {
    Vegeterian_menu* menu_list;
    int size;
}DailyVegeterianMenu;


typedef struct {
    char* name;
    DailyNormalMenu* normal_menu_arr;
    DailyVeganMenu* vegan_menu_arr;
    DailyVegeterianMenu* vegeterian_menu_arr;
}Cafeteria ;

void initialize_menus(Cafeteria *cafeteria, char *csv_file_name);
void record_customer_counts(Cafeteria *cafeteria);
void calc_and_show_income(Cafeteria *cafeteria);

//Here we created Cafeteria and called functions and free the places where we did malloc
int main(){
    Cafeteria cafeteria = {"", NULL, NULL, NULL};
    initialize_menus(&cafeteria, "cafeteria_march_menu.csv");
    record_customer_counts(&cafeteria);
    calc_and_show_income(&cafeteria);

    free(cafeteria.name);
    free(cafeteria.normal_menu_arr->menu_list);
    free(cafeteria.vegan_menu_arr->menu_list);
    free(cafeteria.vegeterian_menu_arr->menu_list);
    free(cafeteria.normal_menu_arr);
    free(cafeteria.vegan_menu_arr);
    free(cafeteria.vegeterian_menu_arr);
    
return 0;

}

void initialize_menus(Cafeteria *cafeteria, char *csv_file_name){
    
char line[1024];
char* token;
FILE* file = fopen("cafeteria_march_menu.csv", "r");


char month_name[30];
fscanf(file, "%[^,],", month_name);


//In this part, we created the necessary places for the structures by doing malloc.
cafeteria->name = (char*) malloc(sizeof(char) * (strlen(month_name) + 1));
strcpy(cafeteria->name, month_name);

cafeteria->normal_menu_arr = (DailyNormalMenu*)malloc(sizeof(DailyNormalMenu));
cafeteria->vegan_menu_arr = (DailyVeganMenu*)malloc(sizeof(DailyVeganMenu));
cafeteria->vegeterian_menu_arr = (DailyVegeterianMenu*)malloc(sizeof(DailyVegeterianMenu));


cafeteria->normal_menu_arr->size = 0;
cafeteria->vegan_menu_arr->size = 0;
cafeteria->vegeterian_menu_arr->size = 0;

//We read the file line by line.
fseek(file, 0, SEEK_SET);
while(fgets(line, 1024, file)){
   
    
        char *p = strchr(line, '"');
        while (p != NULL) {
            memmove(p, p + 1, strlen(p + 1) + 1);
            p = strchr(p, '"');
        }
        
    token = strtok(line, ",");
    char* menu = token;

    token = strtok(NULL, ",");
    char* date = token;

    token = strtok(NULL, ",");
    char* soup = token;

    token = strtok(NULL, ",");
    char* main_dish = token;

    token = strtok(NULL, ",");
    char* side_dish = token;


    token = strtok(NULL, ",");
    char* extra = token;

//We created the necessary menu depending on whether it is normal, vegan or vegetarian, and we assigned the menus to the places we created before with realloc.
   if (strcmp(menu, "Normal") == 0) {
            Normal_menu normal_menu;
            strcpy(normal_menu.date, date);
            strcpy(normal_menu.soup, soup);
            strcpy(normal_menu.main_dish, main_dish);
            strcpy(normal_menu.side_dish, side_dish);
            strcpy(normal_menu.extra, extra);
        
            cafeteria->normal_menu_arr->menu_list = (Normal_menu*) realloc(cafeteria->normal_menu_arr->menu_list, sizeof(Normal_menu) * (cafeteria->normal_menu_arr->size + 1));
            cafeteria->normal_menu_arr->menu_list[cafeteria->normal_menu_arr->size++] = normal_menu;      
        }


     else if (strcmp(menu, "Vegan") == 0) {
            Vegan_menu vegan_menu;
            strcpy(vegan_menu.date, date);
            strcpy(vegan_menu.soup, soup);
            strcpy(vegan_menu.main_dish, main_dish);
            strcpy(vegan_menu.side_dish, side_dish);
            strcpy(vegan_menu.extra, extra);
        
            cafeteria->vegan_menu_arr->menu_list = (Vegan_menu*) realloc(cafeteria->vegan_menu_arr->menu_list, sizeof(Vegan_menu) * (cafeteria->vegan_menu_arr->size + 1));
            cafeteria->vegan_menu_arr->menu_list[cafeteria->vegan_menu_arr->size++] = vegan_menu;      
        }

     else if (strcmp(menu, "Vegetarian") == 0) {
            Vegeterian_menu vegaterian_menu;
            strcpy(vegaterian_menu.date, date);
            strcpy(vegaterian_menu.soup, soup);
            strcpy(vegaterian_menu.main_dish, main_dish);
            strcpy(vegaterian_menu.side_dish, side_dish);
            strcpy(vegaterian_menu.extra, extra);
        
            cafeteria->vegeterian_menu_arr->menu_list = (Vegeterian_menu*) realloc(cafeteria->vegeterian_menu_arr->menu_list, sizeof(Vegeterian_menu) * (cafeteria->vegeterian_menu_arr->size + 1));
            cafeteria->vegeterian_menu_arr->menu_list[cafeteria->vegeterian_menu_arr->size++] = vegaterian_menu;       
        }     

    }
// we close the file.
fclose(file);   
}

//We created student, academic Personal and administrative Personal in the menu lists with random.
void record_customer_counts(Cafeteria *cafeteria){
    int size_normal = cafeteria->normal_menu_arr->size;
    int size_vegan  = cafeteria->vegan_menu_arr->size;
    int size_vegetarian = cafeteria->vegeterian_menu_arr->size;
    srand(time(NULL));
    for (int i = 0 ; i < size_normal ; i++) {
        int studentNumber = rand() % 51;
        int academicPersonalNumber = rand() % 51;
        int administrativePersonalNumber = rand() % 51;
        cafeteria->normal_menu_arr->menu_list[i].sale_count[0] = studentNumber;
        cafeteria->normal_menu_arr->menu_list[i].sale_count[1] = academicPersonalNumber;
        cafeteria->normal_menu_arr->menu_list[i].sale_count[2] = administrativePersonalNumber;
    }

    for (int i = 0 ; i < size_vegan ; i++) {
        int studentNumber = rand() % 51;
        int academicPersonalNumber = rand() % 51;
        int administrativePersonalNumber = rand() % 51;
        cafeteria->vegan_menu_arr->menu_list[i].sale_count[0] = studentNumber;
        cafeteria->vegan_menu_arr->menu_list[i].sale_count[1] = academicPersonalNumber;
        cafeteria->vegan_menu_arr->menu_list[i].sale_count[2] = administrativePersonalNumber;
    }

    for (int i = 0 ; i < size_vegetarian ; i++) {
        int studentNumber = rand() % 51;
        int academicPersonalNumber = rand() % 51;
        int administrativePersonalNumber = rand() % 51;
        cafeteria->vegeterian_menu_arr->menu_list[i].sale_count[0] = studentNumber;
        cafeteria->vegeterian_menu_arr->menu_list[i].sale_count[1] = academicPersonalNumber;
        cafeteria->vegeterian_menu_arr->menu_list[i].sale_count[2] = administrativePersonalNumber;
    }
    
}

//We made the necessary calculations for student, academic Personal and administrative Personnel and menus and printed them on the screen.
void calc_and_show_income(Cafeteria *cafeteria) {
    int size_normal = cafeteria->normal_menu_arr->size;
    int size_vegan  = cafeteria->vegan_menu_arr->size;
    int size_vegetarian = cafeteria->vegeterian_menu_arr->size;

    int studentPrice = 6;
    int academicPersonalPrice = 16;
    int administrativePersonalPrice = 12;

    int totalStudentSales = 0;
    int totalAcademicPersonalSales = 0;
    int totalAdministrativePersonalSales = 0;

    int totalNormalSales = 0;
    int totalVeganSales = 0;
    int totalVegetarianSales = 0;

    int totalSales = 0;

    for (int i = 0 ; i < size_normal ; i++) {
        int studentSales = cafeteria->normal_menu_arr->menu_list[i].sale_count[0] * studentPrice;
        int academicPersonalSales = cafeteria->normal_menu_arr->menu_list[i].sale_count[1] * academicPersonalPrice;
        int administrativePersonalSales = cafeteria->normal_menu_arr->menu_list[i].sale_count[2] * administrativePersonalPrice;

        totalStudentSales += studentSales;
        totalAcademicPersonalSales += academicPersonalSales;
        totalAdministrativePersonalSales += administrativePersonalSales;
        int total = studentSales + academicPersonalSales + administrativePersonalSales;      

        totalNormalSales += total;
    }

    for (int i = 0 ; i < size_vegan ; i++) {
        int studentSales = cafeteria->vegan_menu_arr->menu_list[i].sale_count[0] * studentPrice;
        int academicPersonalSales = cafeteria->vegan_menu_arr->menu_list[i].sale_count[1] * academicPersonalPrice;
        int administrativePersonalSales = cafeteria->vegan_menu_arr->menu_list[i].sale_count[2] * administrativePersonalPrice;

        totalStudentSales += studentSales;
        totalAcademicPersonalSales += academicPersonalSales;
        totalAdministrativePersonalSales += administrativePersonalSales;      

        int total = studentSales + academicPersonalSales + administrativePersonalSales  ;    

        totalVeganSales += total;
    }

    for (int i = 0 ; i < size_vegetarian ; i++) {
        int studentSales = cafeteria->vegeterian_menu_arr->menu_list[i].sale_count[0] * studentPrice;
        int academicPersonalSales = cafeteria->vegeterian_menu_arr->menu_list[i].sale_count[1] * academicPersonalPrice;
        int administrativePersonalSales = cafeteria->vegeterian_menu_arr->menu_list[i].sale_count[2] * administrativePersonalPrice;

        totalStudentSales += studentSales;
        totalAcademicPersonalSales += academicPersonalSales;
        totalAdministrativePersonalSales += administrativePersonalSales;      

        int total = studentSales + academicPersonalSales + administrativePersonalSales  ;    

        totalVegetarianSales += total;
    }
    totalSales = totalNormalSales + totalVeganSales + totalVegetarianSales;


    printf("Normal menu for the first day of the month \n");
    printf("Date: %s \n", cafeteria->normal_menu_arr->menu_list[0].date);
    printf("Soup: %s \n", cafeteria->normal_menu_arr->menu_list[0].soup);
    printf("Main Dish: %s \n", cafeteria->normal_menu_arr->menu_list[0].main_dish);
    printf("Side Dish: %s \n", cafeteria->normal_menu_arr->menu_list[0].side_dish);
    printf("Extra: %s \n", cafeteria->normal_menu_arr->menu_list[0].extra);

    printf("Normal menu for the last day of the month \n");
    int normalMenuSize = (cafeteria->normal_menu_arr->size) - 1;
    printf("Date: %s \n", cafeteria->normal_menu_arr->menu_list[normalMenuSize].date);
    printf("Soup: %s \n", cafeteria->normal_menu_arr->menu_list[normalMenuSize].soup);
    printf("Main Dish: %s \n", cafeteria->normal_menu_arr->menu_list[normalMenuSize].main_dish);
    printf("Side Dish: %s \n", cafeteria->normal_menu_arr->menu_list[normalMenuSize].side_dish);
    printf("Extra: %s \n", cafeteria->normal_menu_arr->menu_list[normalMenuSize].extra);

    printf("Vegan menu for the first day of the month: \n");
    printf("Date: %s \n", cafeteria->vegan_menu_arr->menu_list[0].date);
    printf("Soup: %s \n", cafeteria->vegan_menu_arr->menu_list[0].soup);
    printf("Main Dish: %s \n", cafeteria->vegan_menu_arr->menu_list[0].main_dish);
    printf("Side Dish: %s \n", cafeteria->vegan_menu_arr->menu_list[0].side_dish);
    printf("Extra: %s \n", cafeteria->vegan_menu_arr->menu_list[0].extra);

    printf("Vegan menu for the last day of the month \n");
    int veganMenuSize = (cafeteria->vegan_menu_arr->size) - 1;
    printf("Date: %s \n", cafeteria->vegan_menu_arr->menu_list[veganMenuSize].date);
    printf("Soup: %s \n", cafeteria->vegan_menu_arr->menu_list[veganMenuSize].soup);
    printf("Main Dish: %s \n", cafeteria->vegan_menu_arr->menu_list[veganMenuSize].main_dish);
    printf("Side Dish: %s \n", cafeteria->vegan_menu_arr->menu_list[veganMenuSize].side_dish);
    printf("Extra: %s \n", cafeteria->vegan_menu_arr->menu_list[veganMenuSize].extra);

    printf("Vegetarian menu for the first day of the month: \n");
    printf("Date: %s \n", cafeteria->vegeterian_menu_arr->menu_list[0].date);
    printf("Soup: %s \n", cafeteria->vegeterian_menu_arr->menu_list[0].soup);
    printf("Main Dish: %s \n", cafeteria->vegeterian_menu_arr->menu_list[0].main_dish);
    printf("Side Dish: %s \n", cafeteria->vegeterian_menu_arr->menu_list[0].side_dish);
    printf("Extra: %s \n", cafeteria->vegeterian_menu_arr->menu_list[0].extra);

    printf("Vegetarian menu for the last day of the month \n");
    int vegetarianMenuSize = (cafeteria->vegeterian_menu_arr->size) - 1;
    printf("Date: %s \n", cafeteria->vegeterian_menu_arr->menu_list[vegetarianMenuSize].date);
    printf("Soup: %s \n", cafeteria->vegeterian_menu_arr->menu_list[vegetarianMenuSize].soup);
    printf("Main Dish: %s \n", cafeteria->vegeterian_menu_arr->menu_list[vegetarianMenuSize].main_dish);
    printf("Side Dish: %s \n", cafeteria->vegeterian_menu_arr->menu_list[vegetarianMenuSize].side_dish);
    printf("Extra: %s \n", cafeteria->vegeterian_menu_arr->menu_list[vegetarianMenuSize].extra);

    printf("Example output for normal menu \n");
    printf("Date: %s \n", cafeteria->normal_menu_arr->menu_list[5].date);
    printf("Soup: %s \n", cafeteria->normal_menu_arr->menu_list[5].soup);
    printf("Main Dish: %s \n", cafeteria->normal_menu_arr->menu_list[5].main_dish);
    printf("Side Dish: %s \n", cafeteria->normal_menu_arr->menu_list[5].side_dish);
    printf("Extra: %s \n", cafeteria->normal_menu_arr->menu_list[5].extra);

    printf("Example output for vegan menu \n");
    printf("Date: %s \n", cafeteria->vegan_menu_arr->menu_list[15].date);
    printf("Soup: %s \n", cafeteria->vegan_menu_arr->menu_list[15].soup);
    printf("Main Dish: %s \n", cafeteria->vegan_menu_arr->menu_list[15].main_dish);
    printf("Side Dish: %s \n", cafeteria->vegan_menu_arr->menu_list[15].side_dish);
    printf("Extra: %s \n", cafeteria->vegan_menu_arr->menu_list[15].extra);

    printf("Example output for vegetarian menu \n");
    printf("Date: %s \n", cafeteria->vegeterian_menu_arr->menu_list[12].date);
    printf("Soup: %s \n", cafeteria->vegeterian_menu_arr->menu_list[12].soup);
    printf("Main Dish: %s \n", cafeteria->vegeterian_menu_arr->menu_list[12].main_dish);
    printf("Side Dish: %s \n", cafeteria->vegeterian_menu_arr->menu_list[12].side_dish);
    printf("Extra: %s \n", cafeteria->vegeterian_menu_arr->menu_list[12].extra);

    int studentMarch_9 = cafeteria->normal_menu_arr->menu_list[5].sale_count[0];
    int academicMarch_9 = cafeteria->normal_menu_arr->menu_list[5].sale_count[1];
    int administrativeMarch_9 = cafeteria->normal_menu_arr->menu_list[5].sale_count[2];
    printf("Counts for the example normal menu output of March 8th -> Student:%d, Academic:%d, Administrative:%d \n", studentMarch_9, academicMarch_9, administrativeMarch_9);

    int studentMarch_22 = cafeteria->vegan_menu_arr->menu_list[15].sale_count[0];
    int academicMarch_22 = cafeteria->vegan_menu_arr->menu_list[15].sale_count[1];
    int administrativeMarch_22 = cafeteria->vegan_menu_arr->menu_list[15].sale_count[2];
    printf("Counts for the example vegan menu output of March 22th -> Student:%d, Academic:%d, Administrative:%d \n", studentMarch_22, academicMarch_22, administrativeMarch_22);

    int studentMarch_17 = cafeteria->vegeterian_menu_arr->menu_list[12].sale_count[0];
    int academicMarch_17 = cafeteria->vegeterian_menu_arr->menu_list[12].sale_count[1];
    int administrativeMarch_17 = cafeteria->vegeterian_menu_arr->menu_list[12].sale_count[2];
    printf("Counts for the example vegetarian menu output of March 17th -> Student:%d, Academic:%d, Administrative:%d \n \n", studentMarch_17, academicMarch_17, administrativeMarch_17);

    printf("************ The Sales Results ************ \n \n");

    printf("Normal menu sales: %d TL, Vegan menu sales: %d TL, Vegetarian menu sales: %d TL \n", totalNormalSales, totalVeganSales, totalVegetarianSales);
    printf("Student sales: %d TL, Academic personal sales: %d TL, Administrative personal sales: %d TL \n", totalStudentSales, totalAcademicPersonalSales, totalAdministrativePersonalSales);
    printf("Total sale income: %d TL \n", totalSales);

}

    

