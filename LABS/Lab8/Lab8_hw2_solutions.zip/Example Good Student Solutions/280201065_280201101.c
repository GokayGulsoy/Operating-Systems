#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#define STUDENT_COST 6
#define ACADEMIC_COST 16
#define ADMIN_COST 12
#define bufferSize 192
#define maxRandom 50
#define NORMAL "\"Normal\""
#define VEGAN "\"Vegan\""
#define VEGETARIAN "\"Vegetarian\""
#define comma ","
#define line "-"
#define quotation "\""
// CENG322 HW2 - Group 40 - Yiğit Eren Durmaz - 280201065, Yasir Duman - 280201101
typedef struct Menu {
    char *date;
    char *soup;
    char *mainDish;
    char *sideDish;
    char *extra;
    int saleCount[3];
} Menu;

typedef struct Cafeteria {
    char *monthName;
    Menu *normalMenu;
    Menu *veganMenu;
    Menu *vegetarianMenu;
    int dayCount; // a custom attribute i have added to store the count of days that the cafeteria works. the getDayCount() method is used for this.
} Cafeteria;

int randomInRange(int max) { // returns a number between 0 and max (both inclusive).
    return rand() % (max + 1);
}

char* getMonthName(char *csv_file_name) { // gets the months name from the csv file.
    char strBuffer[bufferSize];
    FILE *fp = fopen(csv_file_name, "r");
    fgets(strBuffer, bufferSize, fp); // get only the first line.
    fclose(fp);
    strtok(strBuffer, comma); // the menu type, not necessary for here
    char *date = strtok(NULL, comma); // date, written as "XX-MONTH"
    strtok(date, line); // day, unnecessary for here
    char *withQuatation = strtok(NULL, line); // the second half of the date as MONTH"
    return strdup(strtok(withQuatation, quotation)); // strtok to get rid of the quotation mark at the end, strdup to avoid potential memory issues.
}

int getDayCount(char *csv_file_name) { // this function counts how many days there are in the csv file.
    char strBuffer[bufferSize];
    FILE *fp = fopen(csv_file_name, "r");
    int counter = 0;
    while(fgets(strBuffer, bufferSize, fp)){
        counter++;
    }
    fclose(fp);
    return counter / 3; // since there are 3 menu types, we divide the total menu number by 3 to obtain the day count.
}

Cafeteria *initialize_cafeteria(char *csv_file_name) { // this function initializes a previously uninitialized cafeteria struct.
    Cafeteria *cafeteria = (Cafeteria*) malloc(sizeof(Cafeteria));
    int dayCount = getDayCount(csv_file_name);
    cafeteria->monthName = getMonthName(csv_file_name);
    cafeteria->normalMenu = (Menu*) malloc(sizeof(Menu) * dayCount);
    cafeteria->veganMenu = (Menu*) malloc(sizeof(Menu) * dayCount);
    cafeteria->vegetarianMenu = (Menu*) malloc(sizeof(Menu) * dayCount);
    cafeteria->dayCount = dayCount;
    return cafeteria;
}
void setMenu(Menu *menu, char *date, char *soup, char *main, char *side, char *extra) { // this function takes an uninitialized menu struct, and initializes it with the given inputs.
    menu->date = strdup(date); // since the given inputs actually share one big string togehter, we have to give them new space with strdup for them to be properly allocated explicitly.
    menu->soup = strdup(soup);
    menu->mainDish = strdup(main);
    menu->sideDish = strdup(side);
    menu->extra = strdup(extra);
    for (int i = 0; i < 3; i++) {
        menu->saleCount[i] = 0; // initialize the sale count array with three zeroes.
    }
}

void initialize_menus(Cafeteria *cafeteria, char *csv_file_name) {
    char strBuffer[bufferSize];
    char *date, *soup, *main, *side, *extra;
    char *menuType;
    int normalIndex = 0;
    int veganIndex = 0;
    int vegetarianIndex = 0;
    Menu *currentMenu;
    FILE *fp = fopen(csv_file_name, "r");
    if(fp == NULL) {
      printf("Error reading file.");
      exit(1);
    }
    while(fgets(strBuffer, bufferSize, fp)) {
        strBuffer[strcspn(strBuffer, "\n")] = 0; // to get rid of the newline character at the end of each line.
        //strcpy(menuType, strtok(strBuffer, comma));
        //the below line was initially like this, however, since strtok simply returns pointers from one big string, we found out strcpy may cause memory problems in this case. strdup is used instead to solve this.
        menuType = strdup(strtok(strBuffer, comma));// feed the line to strtok, and get the menu type.
        date = strtok(NULL, comma); // we have looked at strtok's source code, and because of the unique way it works by setting pointers ahead of previously processed tokens,
        soup = strtok(NULL, comma); // and the way we only process one line at a time, this code segment works without the need of an extra malloc for now.
        main = strtok(NULL, comma);
        side = strtok(NULL, comma);
        extra = strtok(NULL, comma);
        if (strcmp(menuType, NORMAL) == 0) {
            currentMenu = &(cafeteria->normalMenu[normalIndex]);
            setMenu(currentMenu, date, soup, main, side, extra);
            normalIndex++;
        }
        else if (strcmp(menuType, VEGAN) == 0) {
            currentMenu = &(cafeteria->veganMenu[veganIndex]);
            setMenu(currentMenu, date, soup, main, side, extra);
            veganIndex++;
        }
        else  { // vegetarian
            currentMenu = &(cafeteria->vegetarianMenu[vegetarianIndex]);
            setMenu(currentMenu, date, soup, main, side, extra);
            vegetarianIndex++;
        }
        free(menuType); // strdup intenally calls malloc, therefore it needs to be freed on each use to avoid memory leaks.
    }
    fclose(fp);
}

void record_customer_counts(Cafeteria *cafeteria) {
    for (int i = 0; i < cafeteria->dayCount; i++) { // each day in the cafeteria
        for (int j = 0; j < 3; j++) { // students, academic and administrative in order
            cafeteria->normalMenu[i].saleCount[j] = randomInRange(maxRandom); // max random is 50, this will return some integer between 0 and 50 (both inclusive)
            cafeteria->veganMenu[i].saleCount[j] = randomInRange(maxRandom);
            cafeteria->vegetarianMenu[i].saleCount[j] = randomInRange(maxRandom);  
        }
    }
}

void calc_and_show_income(Cafeteria *cafeteria) {
    int currentCustomerTotal;
    Menu currentMenu;
    Menu *menus[3] = {cafeteria->normalMenu, cafeteria->veganMenu, cafeteria->vegetarianMenu};
    int menuSales[3] = {0 , 0, 0}; // normal, vegan, vegetarian
    int customerSales[3] = {0, 0, 0}; // student, academic, admin
    int costMultipliers[3] = {STUDENT_COST, ACADEMIC_COST, ADMIN_COST};

    // i j k ordered for loop, with cache efficiency in mind
    for (int i = 0; i < 3; i++) { // for each menu type 
        for (int j = 0; j < cafeteria->dayCount; j++) { // for each day
            currentMenu = menus[i][j]; // type of menu + a day
            for (int k = 0; k < 3; k++) { // for each customer type
                currentCustomerTotal = currentMenu.saleCount[k] * costMultipliers[k]; // customer sale count * cost of that person's meal
                customerSales[k] += currentCustomerTotal; // add it to the customer type's total sales, such as student or academic
                menuSales[i] += currentCustomerTotal; // add it to the menu type's total sales, such as normal or vegan
            }
        }
    }
    printf("\n************ The Sales Results ************\n\n");

    printf("Normal menu sales: %d TL\n", menuSales[0]);
    printf("Vegan menu sales: %d TL\n", menuSales[1]);
    printf("Vegetarian menu sales: %d TL\n\n", menuSales[2]);

    printf("Student sales: %d TL\n", customerSales[0]);
    printf("Academic personnel sales: %d TL\n", customerSales[1]);
    printf("Administrative staff sales: %d TL\n\n", customerSales[2]);

    printf("Total sale income: %d TL\n", menuSales[0] + menuSales[1] + menuSales[2]);

}

void printRandomDays(Cafeteria *cafeteria) { // prints normal, vegan and vegetarian menus from random days to show that the structs are working properly.
    int normalIndex = randomInRange(cafeteria->dayCount-1);
    int veganIndex = randomInRange(cafeteria->dayCount-1);
    int vegetarianIndex = randomInRange(cafeteria->dayCount-1);
    Menu normalMenu = cafeteria->normalMenu[normalIndex];
    Menu veganMenu = cafeteria->veganMenu[veganIndex];
    Menu vegetarianMenu = cafeteria->vegetarianMenu[vegetarianIndex];
    printf("Printing a random normal, vegan and vegetarian menu from this month:\n\n");
    printf("Normal menu on %s: %s | %s | %s | %s\n", normalMenu.date, normalMenu.soup, normalMenu.mainDish, normalMenu.sideDish, normalMenu.extra);
    printf("Sold to: %d Students, %d Academic Personnel, %d Administrative Staff.\n\n", normalMenu.saleCount[0], normalMenu.saleCount[1], normalMenu.saleCount[2]);

    printf("Vegan menu on %s: %s | %s | %s | %s\n", veganMenu.date, veganMenu.soup, veganMenu.mainDish, veganMenu.sideDish, veganMenu.extra);
    printf("Sold to: %d Students, %d Academic Personnel, %d Administrative Staff.\n\n", veganMenu.saleCount[0], veganMenu.saleCount[1], veganMenu.saleCount[2]);

    printf("Vegetarian menu on %s: %s | %s | %s | %s\n", vegetarianMenu.date, vegetarianMenu.soup, vegetarianMenu.mainDish, vegetarianMenu.sideDish, vegetarianMenu.extra);
    printf("Sold to: %d Students, %d Academic Personnel, %d Administrative Staff.\n\n", vegetarianMenu.saleCount[0], vegetarianMenu.saleCount[1], vegetarianMenu.saleCount[2]);
}

void freeMemory(Cafeteria *cafeteria) {
    int loopCount = cafeteria->dayCount;
    Menu *menus[] = {cafeteria->normalMenu, cafeteria->veganMenu, cafeteria->vegetarianMenu};
    Menu *currentMenu;
    for (int i = 0; i < 3; i++) { // for each menu type
        for (int j = 0; j < loopCount; j++) { // for each day
            currentMenu = &menus[i][j];
            free(currentMenu->date);
            free(currentMenu->soup);
            free(currentMenu->mainDish);
            free(currentMenu->sideDish);
            free(currentMenu->extra);
        }
        free(menus[i]); // since one big malloc actually allocates the menu array, we only need to free this first reference.
    }
    free(cafeteria->monthName); // finally, free cafeteria related allocations.
    free(cafeteria);
}

void simulateCafetaria(char* filepath) {
    srand(time(NULL)); // to ensure random outputs in each execution
    Cafeteria *cafeteria;
    cafeteria = initialize_cafeteria(filepath);
    initialize_menus(cafeteria, filepath); 
    record_customer_counts(cafeteria);
    printRandomDays(cafeteria);
    calc_and_show_income(cafeteria);
    freeMemory(cafeteria);
}

int main() {
    char* filepath = "cafeteria_march_menu.csv";
    simulateCafetaria(filepath);
    return 0;
}